#!/bin/bash

echo "🚀 Lancement du tunnel Serveo..."
echo "🎯 Redirection du port local 4444 (TCP) via Serveo"

# Lancement du tunnel Serveo avec port aléatoire et extraction de l'URL publique
ssh -R 0:localhost:4444 serveo.net | tee serveo_log.txt | while read line; do
    echo "$line"
    if [[ "$line" == *"Forwarding TCP connections from"* ]]; then
        echo ""
        echo "🌍 Ton socket est dispo ici :"
        echo "👉 $(echo $line | awk '{print $5}')"
        echo ""
    fi
done
