
from cx_Freeze import setup, Executable

setup(
    name="RemoteClient",
    version="1.0",
    description="Client furtif",
    executables=[
        Executable("virus.py", base="Win32GUI")
    ]
)
